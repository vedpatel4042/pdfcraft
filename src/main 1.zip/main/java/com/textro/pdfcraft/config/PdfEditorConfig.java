package com.textro.pdfcraft.config;

public class PdfEditorConfig {

}
