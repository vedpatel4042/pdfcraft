// Add PDF.js initialization
pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.worker.min.js';
// PDF Editor Frontend JavaScript
class PdfEditor {
   constructor(sessionId, pageNumber) {
    this.sessionId = sessionId;
    this.currentPage = pageNumber;
    this.isEditing = false;
    this.selectedTextId = null;
    this.zoomLevel = 1.0;
    this.pageCount = 1;
    this.pdfDoc = null; 
    this.init();
}

    init() {
        this.bindEvents();
        this.loadPage();
        this.updatePageInfo();
    }

    bindEvents() {
        // PDF click event for adding text
        const pdfPage = document.getElementById('pdfPage');
        if (pdfPage) {
            pdfPage.addEventListener('click', (e) => this.handlePdfClick(e));
            pdfPage.addEventListener('contextmenu', (e) => this.handleRightClick(e));
        }

        // Edit form events
        const saveBtn = document.getElementById('saveEditBtn');
        const cancelBtn = document.getElementById('cancelEditBtn');
        const deleteBtn = document.getElementById('deleteTextBtn');

        if (saveBtn) saveBtn.addEventListener('click', () => this.saveEdit());
        if (cancelBtn) cancelBtn.addEventListener('click', () => this.cancelEdit());
        if (deleteBtn) deleteBtn.addEventListener('click', () => this.deleteText());

        // Page navigation
        const prevBtn = document.getElementById('prevPageBtn');
        const nextBtn = document.getElementById('nextPageBtn');

        if (prevBtn) prevBtn.addEventListener('click', () => this.previousPage());
        if (nextBtn) nextBtn.addEventListener('click', () => this.nextPage());

        // Zoom controls
        const zoomInBtn = document.getElementById('zoomInBtn');
        const zoomOutBtn = document.getElementById('zoomOutBtn');

        if (zoomInBtn) zoomInBtn.addEventListener('click', () => this.zoomIn());
        if (zoomOutBtn) zoomOutBtn.addEventListener('click', () => this.zoomOut());

        // File operations
        const downloadBtn = document.getElementById('downloadBtn');
        const saveBtn2 = document.getElementById('saveDocBtn');

        if (downloadBtn) downloadBtn.addEventListener('click', () => this.downloadPdf());
        if (saveBtn2) saveBtn2.addEventListener('click', () => this.saveDocument());

        // Page operations
        const addPageBtn = document.getElementById('addPageBtn');
        const deletePageBtn = document.getElementById('deletePageBtn');

        if (addPageBtn) addPageBtn.addEventListener('click', () => this.addPage());
        if (deletePageBtn) deletePageBtn.addEventListener('click', () => this.deletePage());

        // Merge and split operations
        const mergeBtn = document.getElementById('mergeBtn');
        const splitBtn = document.getElementById('splitBtn');

        if (mergeBtn) mergeBtn.addEventListener('click', () => this.showMergeModal());
        if (splitBtn) splitBtn.addEventListener('click', () => this.showSplitModal());

        // Close modal on outside click
        window.addEventListener('click', (e) => {
            const modal = document.getElementById('editModal');
            if (e.target === modal) {
                this.cancelEdit();
            }
        });

        // ESC key to cancel edit
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.isEditing) {
                this.cancelEdit();
            }
        });

        // File upload for merge
        const mergeFileInput = document.getElementById('mergeFileInput');
        if (mergeFileInput) {
            mergeFileInput.addEventListener('change', (e) => this.handleMergeFile(e));
        }
    }

    handlePdfClick(e) {
        if (this.isEditing) return;

        const rect = e.currentTarget.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        this.showEditModal(x, y, null, 'add');
    }

    handleRightClick(e) {
        e.preventDefault();
        const rect = e.currentTarget.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        // Check if clicking on existing text
        const textId = this.getTextIdAtPosition(x, y);
        if (textId) {
            this.showEditModal(x, y, textId, 'edit');
        }
    }

    showEditModal(x, y, textId, mode) {
        const modal = document.getElementById('editModal');
        const modalContent = document.querySelector('.modal-content');

        if (!modal || !modalContent) {
            console.error('Edit modal not found');
            return;
        }

        // Position modal
        modal.style.display = 'block';
        modalContent.style.left = (x + 10) + 'px';
        modalContent.style.top = (y + 10) + 'px';

        // Set form values
        document.getElementById('editSessionId').value = this.sessionId;
        document.getElementById('editPageNumber').value = this.currentPage;
        document.getElementById('editX').value = x;
        document.getElementById('editY').value = y;
        document.getElementById('editTextId').value = textId || '';

        // Set mode
        this.isEditing = true;
        this.selectedTextId = textId;

        // Update modal title and button text
        const modalTitle = document.querySelector('.modal-title');
        const saveBtn = document.getElementById('saveEditBtn');
        const deleteBtn = document.getElementById('deleteTextBtn');

        if (mode === 'add') {
            modalTitle.textContent = 'Add Text';
            saveBtn.textContent = 'Add Text';
            deleteBtn.style.display = 'none';
            document.getElementById('editText').value = '';
        } else {
            modalTitle.textContent = 'Edit Text';
            saveBtn.textContent = 'Update Text';
            deleteBtn.style.display = 'inline-block';
            // Load existing text data
            this.loadTextData(textId);
        }

        // Focus on text input
        document.getElementById('editText').focus();
    }

    async loadTextData(textId) {
        try {
            const response = await fetch(`/api/pdf/text/${textId}`, {
                method: 'GET',
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            if (response.ok) {
                const textData = await response.json();
                document.getElementById('editText').value = textData.text || '';
                document.getElementById('editFontSize').value = textData.fontSize || 12;
                document.getElementById('editFontFamily').value = textData.fontFamily || 'helvetica';
                document.getElementById('editColor').value = textData.color || '#000000';
            }
        } catch (error) {
            console.error('Error loading text data:', error);
        }
    }

    async saveEdit() {
        const request = {
            sessionId: document.getElementById('editSessionId').value,
            pageNumber: parseInt(document.getElementById('editPageNumber').value),
            textId: document.getElementById('editTextId').value,
            text: document.getElementById('editText').value,
            x: parseFloat(document.getElementById('editX').value),
            y: parseFloat(document.getElementById('editY').value),
            fontSize: parseFloat(document.getElementById('editFontSize').value) || 12,
            fontFamily: document.getElementById('editFontFamily').value || 'helvetica',
            color: document.getElementById('editColor').value || '#000000'
        };

        try {
            let url, method;

            if (request.textId) {
                // Edit existing text
                url = '/api/pdf/text/edit';
                method = 'PUT';
            } else {
                // Add new text
                url = '/api/pdf/text/add';
                method = 'POST';
            }

            const response = await fetch(url, {
                method: method,
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(request)
            });

            if (response.ok) {
                this.cancelEdit();
                this.loadPage();
                this.showNotification('Text saved successfully!', 'success');
            } else {
                const error = await response.text();
                this.showNotification(`Error: ${error}`, 'error');
            }
        } catch (error) {
            console.error('Error saving text:', error);
            this.showNotification('Error saving text', 'error');
        }
    }

    async deleteText() {
        if (!this.selectedTextId) return;

        if (!confirm('Are you sure you want to delete this text?')) return;

        try {
            const response = await fetch('/api/pdf/text/delete', {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    sessionId: this.sessionId,
                    pageNumber: this.currentPage,
                    textId: this.selectedTextId
                })
            });

            if (response.ok) {
                this.cancelEdit();
                this.loadPage();
                this.showNotification('Text deleted successfully!', 'success');
            } else {
                const error = await response.text();
                this.showNotification(`Error: ${error}`, 'error');
            }
        } catch (error) {
            console.error('Error deleting text:', error);
            this.showNotification('Error deleting text', 'error');
        }
    }

    cancelEdit() {
        this.isEditing = false;
        this.selectedTextId = null;
        const modal = document.getElementById('editModal');
        if (modal) {
            modal.style.display = 'none';
        }
    }

    async loadPage() {
    try {
        if (!this.pdfDoc) {
            const loadingTask = pdfjsLib.getDocument(`/api/pdf/document/${this.sessionId}`);
            this.pdfDoc = await loadingTask.promise;
            this.pageCount = this.pdfDoc.numPages;
        }
        
        const page = await this.pdfDoc.getPage(this.currentPage);
        const canvas = document.getElementById('pdfCanvas');
        const context = canvas.getContext('2d');
        const viewport = page.getViewport({ scale: this.zoomLevel });
        
        canvas.height = viewport.height;
        canvas.width = viewport.width;
        
        await page.render({
            canvasContext: context,
            viewport: viewport
        }).promise;
        
        this.updatePageDisplay();
    } catch (error) {
        console.error('Error loading page:', error);
        this.showNotification('Error loading page', 'error');
    }
}
    // async loadPage() {
    //     try {
    //         const response = await fetch(`/api/pdf/page/${this.sessionId}/${this.currentPage}?dpi=150`, {
    //             method: 'GET'
    //         });

    //         if (response.ok) {
    //             const blob = await response.blob();
    //             const imageUrl = URL.createObjectURL(blob);
    //             const pdfPage = document.getElementById('pdfPage');
    //             if (pdfPage) {
    //                 pdfPage.src = imageUrl;
    //                 pdfPage.style.transform = `scale(${this.zoomLevel})`;
    //             }
    //         } else {
    //             this.showNotification('Error loading page', 'error');
    //         }
    //     } catch (error) {
    //         console.error('Error loading page:', error);
    //         this.showNotification('Error loading page', 'error');
    //     }
    // }

    async updatePageInfo() {
        try {
            const response = await fetch(`/api/pdf/info/${this.sessionId}`, {
                method: 'GET'
            });

            if (response.ok) {
                const info = await response.json();
                this.pageCount = info.pageCount;
                this.updatePageDisplay();
            }
        } catch (error) {
            console.error('Error getting page info:', error);
        }
    }

    updatePageDisplay() {
        const pageInfo = document.getElementById('pageInfo');
        if (pageInfo) {
            pageInfo.textContent = `Page ${this.currentPage} of ${this.pageCount}`;
        }

        const prevBtn = document.getElementById('prevPageBtn');
        const nextBtn = document.getElementById('nextPageBtn');

        if (prevBtn) prevBtn.disabled = this.currentPage <= 1;
        if (nextBtn) nextBtn.disabled = this.currentPage >= this.pageCount;
    }

    async previousPage() {
        if (this.currentPage > 1) {
            this.currentPage--;
            await this.loadPage();
            this.updatePageDisplay();
        }
    }

    async nextPage() {
        if (this.currentPage < this.pageCount) {
            this.currentPage++;
            await this.loadPage();
            this.updatePageDisplay();
        }
    }

    zoomIn() {
        this.zoomLevel = Math.min(this.zoomLevel + 0.1, 3.0);
        this.applyZoom();
    }

    zoomOut() {
        this.zoomLevel = Math.max(this.zoomLevel - 0.1, 0.5);
        this.applyZoom();
    }

    applyZoom() {
        const pdfPage = document.getElementById('pdfPage');
        if (pdfPage) {
            pdfPage.style.transform = `scale(${this.zoomLevel})`;
        }

        const zoomDisplay = document.getElementById('zoomLevel');
        if (zoomDisplay) {
            zoomDisplay.textContent = `${Math.round(this.zoomLevel * 100)}%`;
        }
    }

    async addPage() {
        try {
            const response = await fetch('/api/pdf/page/add', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    sessionId: this.sessionId,
                    position: this.currentPage + 1,
                    pageType: 'blank'
                })
            });

            if (response.ok) {
                const result = await response.json();
                this.pageCount = result.pageCount;
                this.currentPage = this.currentPage + 1;
                await this.loadPage();
                this.updatePageDisplay();
                this.showNotification('Page added successfully!', 'success');
            } else {
                this.showNotification('Error adding page', 'error');
            }
        } catch (error) {
            console.error('Error adding page:', error);
            this.showNotification('Error adding page', 'error');
        }
    }

    async deletePage() {
        if (this.pageCount <= 1) {
            this.showNotification('Cannot delete the last page', 'warning');
            return;
        }

        if (!confirm('Are you sure you want to delete this page?')) return;

        try {
            const response = await fetch('/api/pdf/page/delete', {
                method: 'DELETE',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    sessionId: this.sessionId,
                    pageNumber: this.currentPage
                })
            });

            if (response.ok) {
                const result = await response.json();
                this.pageCount = result.pageCount;

                if (this.currentPage > this.pageCount) {
                    this.currentPage = this.pageCount;
                }

                await this.loadPage();
                this.updatePageDisplay();
                this.showNotification('Page deleted successfully!', 'success');
            } else {
                this.showNotification('Error deleting page', 'error');
            }
        } catch (error) {
            console.error('Error deleting page:', error);
            this.showNotification('Error deleting page', 'error');
        }
    }

    showMergeModal() {
        const modal = document.getElementById('mergeModal');
        if (modal) {
            modal.style.display = 'block';
        }
    }

    showSplitModal() {
        const modal = document.getElementById('splitModal');
        if (modal) {
            modal.style.display = 'block';
            document.getElementById('splitAtPage').value = this.currentPage;
        }
    }

    async handleMergeFile(e) {
        const file = e.target.files[0];
        if (!file) return;

        const formData = new FormData();
        formData.append('file', file);
        formData.append('sessionId', this.sessionId);

        try {
            const response = await fetch('/api/pdf/merge', {
                method: 'POST',
                body: formData
            });

            if (response.ok) {
                const result = await response.json();
                this.pageCount = result.pageCount;
                this.updatePageDisplay();
                this.showNotification('PDF merged successfully!', 'success');
                this.closeMergeModal();
            } else {
                this.showNotification('Error merging PDF', 'error');
            }
        } catch (error) {
            console.error('Error merging PDF:', error);
            this.showNotification('Error merging PDF', 'error');
        }
    }

    async splitPdf() {
        const splitAtPage = parseInt(document.getElementById('splitAtPage').value);

        if (splitAtPage < 1 || splitAtPage > this.pageCount) {
            this.showNotification('Invalid page number', 'error');
            return;
        }

        try {
            const response = await fetch('/api/pdf/split', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    sessionId: this.sessionId,
                    splitAtPage: splitAtPage
                })
            });

            if (response.ok) {
                const result = await response.json();
                this.showNotification(`PDF split successfully! New session ID: ${result.newSessionId}`, 'success');
                this.updatePageInfo();
                this.closeSplitModal();
            } else {
                this.showNotification('Error splitting PDF', 'error');
            }
        } catch (error) {
            console.error('Error splitting PDF:', error);
            this.showNotification('Error splitting PDF', 'error');
        }
    }

    closeMergeModal() {
        const modal = document.getElementById('mergeModal');
        if (modal) {
            modal.style.display = 'none';
        }
    }

    closeSplitModal() {
        const modal = document.getElementById('splitModal');
        if (modal) {
            modal.style.display = 'none';
        }
    }

    async downloadPdf() {
        try {
            const response = await fetch(`/api/pdf/download/${this.sessionId}`, {
                method: 'GET'
            });

            if (response.ok) {
                const blob = await response.blob();
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = `edited_document_${new Date().getTime()}.pdf`;
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                window.URL.revokeObjectURL(url);
                this.showNotification('PDF downloaded successfully!', 'success');
            } else {
                this.showNotification('Error downloading PDF', 'error');
            }
        } catch (error) {
            console.error('Error downloading PDF:', error);
            this.showNotification('Error downloading PDF', 'error');
        }
    }

    async saveDocument() {
        try {
            const response = await fetch(`/api/pdf/save/${this.sessionId}`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            });

            if (response.ok) {
                this.showNotification('Document saved successfully!', 'success');
            } else {
                this.showNotification('Error saving document', 'error');
            }
        } catch (error) {
            console.error('Error saving document:', error);
            this.showNotification('Error saving document', 'error');
        }
    }

    getTextIdAtPosition(x, y) {
        // This would need to be implemented based on how you track text positions
        // For now, returning null as placeholder
        return null;
    }

    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;

        notification.style.cssText = `
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 12px 24px;
            border-radius: 4px;
            color: white;
            font-weight: bold;
            z-index: 10000;
            min-width: 250px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        `;

        switch (type) {
            case 'success':
                notification.style.backgroundColor = '#4CAF50';
                break;
            case 'error':
                notification.style.backgroundColor = '#f44336';
                break;
            case 'warning':
                notification.style.backgroundColor = '#ff9800';
                break;
            default:
                notification.style.backgroundColor = '#2196F3';
        }

        document.body.appendChild(notification);

        setTimeout(() => {
            notification.remove();
        }, 5000);
    }

    // Cleanup method to call when component is destroyed
    destroy() {
        // Clean up any event listeners or resources
        this.isEditing = false;
        this.selectedTextId = null;
    }
}

// Utility functions for PDF operations
class PdfUtils {

    async handleUpload() {
    const fileInput = document.getElementById('pdfUpload');
    const file = fileInput.files[0];
    
    if (!file) {
        alert('Please select a PDF file first');
        return;
    }
    
    const formData = new FormData();
    formData.append('file', file);
    formData.append('mode', 'editor');
    
    try {
        const response = await fetch('/api/upload', {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            throw new Error('Upload failed');
        }
        
        const result = await response.json();
        
        if (result.success) {
            window.pdfEditor = new PdfEditor(result.sessionId, 1);
            document.getElementById('pdfContainer').style.display = 'block';
            await window.pdfEditor.loadPage();
        } else {
            alert('Upload failed: ' + (result.error || 'Unknown error'));
        }
    } catch (error) {
        console.error('Upload error:', error);
        alert('Upload error: ' + error.message);
    }
}
    // Add this to your PdfUtils class
    static async uploadPdf(file, mode = 'editor', onSuccess, onError) {
        const formData = new FormData();
        formData.append('file', file);
        formData.append('mode', mode);

        try {
            const response = await fetch('/api/upload', {
                method: 'POST',
                body: formData
            });

            if (response.ok) {
                const result = await response.json();
                if (result.success) {
                    onSuccess(result);
                } else {
                    onError(result.error || 'Upload failed');
                }
            } else {
                const error = await response.text();
                onError(error);
            }
        } catch (error) {
            onError(error.message);
        }
    }
}

// Example usage:
// document.getElementById('pdfUpload').addEventListener('change', async (e) => {
//     const file = e.target.files[0];
//     if (!file) return;

//     PdfUtils.uploadPdf(file, 'editor',
//         (result) => {
//             console.log('Upload successful:', result);
//             // Initialize editor with the new session
//             window.pdfEditor = new PdfEditor(result.sessionId, 1);
//         },
//         (error) => {
//             console.error('Upload failed:', error);
//             alert('Upload failed: ' + error);
//         }
//     );
// });

   document.getElementById('pdfUpload').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    
    console.log("Selected file:", file.name, file.size, file.type);
    
    const formData = new FormData();
    formData.append('file', file);
    formData.append('mode', 'editor');
    
    try {
        const response = await fetch('/api/upload', {
            method: 'POST',
            body: formData,
            // Don't set Content-Type header - let browser set it
        });
        
        console.log("Response status:", response.status);
        const result = await response.json();
        console.log("Response data:", result);
        
        if (response.ok) {
            alert("Upload successful! Session ID: " + result.sessionId);
        } else {
            alert("Upload failed: " + (result.error || response.statusText));
        }
    } catch (error) {
        console.error("Upload error:", error);
        alert("Upload error: " + error.message);
    }
});

    // static async uploadPdf(file, onSuccess, onError) {
    //     const formData = new FormData();
    //     formData.append('file', file);

    //     try {
    //         const response = await fetch('/api/pdf/upload', {
    //             method: 'POST',
    //             body: formData
    //         });

    //         if (response.ok) {
    //             const result = await response.json();
    //             onSuccess(result);
    //         } else {
    //             const error = await response.text();
    //             onError(error);
    //         }
    //     } catch (error) {
    //         onError(error.message);
    //     }
    // }

    // Move these static methods inside PdfUtils class above:
PdfUtils.getPdfInfo = async function(file, onSuccess, onError) {
    const formData = new FormData();
    formData.append('file', file);

    try {
        const response = await fetch('/api/pdf/info', {
            method: 'POST',
            body: formData
        });

        if (response.ok) {
            const info = await response.json();
            onSuccess(info);
        } else {
            const error = await response.text();
            onError(error);
        }
    } catch (error) {
        onError(error.message);
    }
};

PdfUtils.extractText = async function(file, onSuccess, onError) {
    const formData = new FormData();
    formData.append('file', file);

    try {
        const response = await fetch('/api/pdf/extract-text', {
            method: 'POST',
            body: formData
        });

        if (response.ok) {
            const text = await response.text();
            onSuccess(text);
        } else {
            const error = await response.text();
            onError(error);
        }
    } catch (error) {
        onError(error.message);
    }
};

// Initialize PDF Editor when page loads
document.addEventListener('DOMContentLoaded', function () {
    const sessionId = document.getElementById('sessionId')?.value;
    const pageNumber = parseInt(document.getElementById('pageNumber')?.value) || 1;

    if (sessionId) {
        window.pdfEditor = new PdfEditor(sessionId, pageNumber);
    }
});

// Export for module usage
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { PdfEditor, PdfUtils };
}

